import os
os.environ["CUDA_VISIBLE_DEVICES"]="0"
import keras

# import keras_retinanet
from keras_retinanet import models
from keras_retinanet.utils.image import read_image_bgr, preprocess_image, resize_image
from keras_retinanet.utils.visualization import draw_box, draw_caption
from keras_retinanet.utils.colors import label_color
from keras_retinanet.utils.gpu import setup_gpu
import pdb
# import miscellaneous modules
import matplotlib.pyplot as plt
import cv2
import os
import numpy as np
import time

# use this to change which GPU to use
gpu = 0
setup_gpu(gpu)


version = 'resnet101_csv_10.h5.frozen'
#model_path = os.path.join('/ext/alisher/keras-retinanet/resnet152/')
model_path = os.path.join('/ext/alisher/keras-retinanet/big_obj.resnet101/')
#model_path = os.path.join('/ext/alisher/keras-retinanet/all_obj.resnet101/')
#model_path = os.path.join('/ext/alisher/keras-retinanet/resized_1666x1000_custom_config_augmentation/')


model_path = model_path + version


#model_path = '/ext/alisher/keras-retinanet/aug.pedestrian_car/resnet50_csv_01.h5.frozen'
model = models.load_model(model_path, backbone_name='resnet50')


labels_to_names = {0: 'Pedestrian', 1: 'Car'}
video_dir = '/ext/signate_edge_ai/train_videos/train_00'
images_path = os.listdir(video_dir)



if not os.path.exists(video_dir + '_detections'):
    os.mkdir(video_dir + '_detections')



for imname in images_path:
    impath = video_dir + '/' + imname
    image = read_image_bgr(impath)
    draw = image.copy()
    draw = cv2.cvtColor(draw, cv2.COLOR_BGR2RGB)
    # preprocess image for network
    image = preprocess_image(image)

    #image, scale = resize_image(image)
    scale = 1
    start = time.time()
    boxes, scores, labels = model.predict_on_batch(np.expand_dims(image, axis=0))
    #boxes = non_max_suppression_fast(boxes[0], 0.4)
    #boxes = np.float32(np.expand_dims(boxes, 0))
    print("processing time: ", time.time() - start)
    boxes /= scale

    # visualize detections
    for box, score, label in zip(boxes[0], scores[0], labels[0]):
        # scores are sorted so we can break
        if label > 1:
            continue
        if score < 0.5:
            break
        
        color = label_color(label)
        b = box.astype(int)
        draw_box(draw, b, color=color)
    
        caption = "{} {:.3f}".format(labels_to_names[label], score)
        draw_caption(draw, b, caption)
    draw = cv2.cvtColor(draw, cv2.COLOR_BGR2RGB)

    cv2.imwrite(video_dir + '_detections/' + imname, draw)

